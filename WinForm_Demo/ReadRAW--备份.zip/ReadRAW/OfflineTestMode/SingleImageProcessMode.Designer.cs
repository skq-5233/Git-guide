﻿namespace ReadRAW.OfflineTestMode
{
    partial class SingleImageProcessMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode547 = new System.Windows.Forms.TreeNode("Autumn");
            System.Windows.Forms.TreeNode treeNode548 = new System.Windows.Forms.TreeNode("Bone");
            System.Windows.Forms.TreeNode treeNode549 = new System.Windows.Forms.TreeNode("Jet");
            System.Windows.Forms.TreeNode treeNode550 = new System.Windows.Forms.TreeNode("Winter");
            System.Windows.Forms.TreeNode treeNode551 = new System.Windows.Forms.TreeNode("Rainbow");
            System.Windows.Forms.TreeNode treeNode552 = new System.Windows.Forms.TreeNode("Ocean");
            System.Windows.Forms.TreeNode treeNode553 = new System.Windows.Forms.TreeNode("Summer");
            System.Windows.Forms.TreeNode treeNode554 = new System.Windows.Forms.TreeNode("Spring");
            System.Windows.Forms.TreeNode treeNode555 = new System.Windows.Forms.TreeNode("Cool");
            System.Windows.Forms.TreeNode treeNode556 = new System.Windows.Forms.TreeNode("Hsv");
            System.Windows.Forms.TreeNode treeNode557 = new System.Windows.Forms.TreeNode("Pink");
            System.Windows.Forms.TreeNode treeNode558 = new System.Windows.Forms.TreeNode("Hot");
            System.Windows.Forms.TreeNode treeNode559 = new System.Windows.Forms.TreeNode("Parula");
            System.Windows.Forms.TreeNode treeNode560 = new System.Windows.Forms.TreeNode("Magma");
            System.Windows.Forms.TreeNode treeNode561 = new System.Windows.Forms.TreeNode("Inferno");
            System.Windows.Forms.TreeNode treeNode562 = new System.Windows.Forms.TreeNode("Plasma");
            System.Windows.Forms.TreeNode treeNode563 = new System.Windows.Forms.TreeNode("Viridis");
            System.Windows.Forms.TreeNode treeNode564 = new System.Windows.Forms.TreeNode("Cividis");
            System.Windows.Forms.TreeNode treeNode565 = new System.Windows.Forms.TreeNode("Twilight");
            System.Windows.Forms.TreeNode treeNode566 = new System.Windows.Forms.TreeNode("TwilightShifted");
            System.Windows.Forms.TreeNode treeNode567 = new System.Windows.Forms.TreeNode("Turbo");
            this.uiButton1_Load_Img = new Sunny.UI.UIButton();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.uiButton2_SaveImg = new Sunny.UI.UIButton();
            this.uiComboBox1 = new Sunny.UI.UIComboBox();
            this.uiComboBox2 = new Sunny.UI.UIComboBox();
            this.heatmapUiComboTreeView1 = new Sunny.UI.UIComboTreeView();
            this.imageFormatLabel1 = new System.Windows.Forms.Label();
            this.testModeLabel2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.upperThresholdLabel3 = new System.Windows.Forms.Label();
            this.lowerThresholdLabel4 = new System.Windows.Forms.Label();
            this.upThresholdTextBox1 = new System.Windows.Forms.TextBox();
            this.lowThresholdTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.heatMapLabel1 = new System.Windows.Forms.Label();
            this.pixelValueLabel1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiButton1_Load_Img
            // 
            this.uiButton1_Load_Img.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1_Load_Img.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1_Load_Img.Location = new System.Drawing.Point(14, 34);
            this.uiButton1_Load_Img.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1_Load_Img.Name = "uiButton1_Load_Img";
            this.uiButton1_Load_Img.Size = new System.Drawing.Size(100, 52);
            this.uiButton1_Load_Img.TabIndex = 8;
            this.uiButton1_Load_Img.Text = "打开图像";
            this.uiButton1_Load_Img.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1_Load_Img.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton1_Load_Img.Click += new System.EventHandler(this.Load_Raw_Img_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(99, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 512);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // uiButton2_SaveImg
            // 
            this.uiButton2_SaveImg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton2_SaveImg.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton2_SaveImg.Location = new System.Drawing.Point(14, 109);
            this.uiButton2_SaveImg.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton2_SaveImg.Name = "uiButton2_SaveImg";
            this.uiButton2_SaveImg.Size = new System.Drawing.Size(100, 52);
            this.uiButton2_SaveImg.TabIndex = 11;
            this.uiButton2_SaveImg.Text = "保存图像";
            this.uiButton2_SaveImg.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton2_SaveImg.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton2_SaveImg.Click += new System.EventHandler(this.SaveImg_Click);
            // 
            // uiComboBox1
            // 
            this.uiComboBox1.DataSource = null;
            this.uiComboBox1.FillColor = System.Drawing.Color.White;
            this.uiComboBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiComboBox1.Location = new System.Drawing.Point(102, 23);
            this.uiComboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox1.Name = "uiComboBox1";
            this.uiComboBox1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox1.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox1.TabIndex = 12;
            this.uiComboBox1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox1.Watermark = "";
            this.uiComboBox1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiComboBox1.SelectedIndexChanged += new System.EventHandler(this.uiComboBox1_SelectedIndexChanged);
            // 
            // uiComboBox2
            // 
            this.uiComboBox2.DataSource = null;
            this.uiComboBox2.DropDownWidth = 300;
            this.uiComboBox2.FillColor = System.Drawing.Color.White;
            this.uiComboBox2.FilterMaxCount = 50;
            this.uiComboBox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboBox2.Location = new System.Drawing.Point(102, 60);
            this.uiComboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox2.Name = "uiComboBox2";
            this.uiComboBox2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox2.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox2.TabIndex = 77;
            this.uiComboBox2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox2.Watermark = "";
            this.uiComboBox2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiComboBox2.SelectedIndexChanged += new System.EventHandler(this.uiComboBox2_SelectedIndexChanged);
            // 
            // heatmapUiComboTreeView1
            // 
            this.heatmapUiComboTreeView1.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.heatmapUiComboTreeView1.FillColor = System.Drawing.Color.White;
            this.heatmapUiComboTreeView1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.heatmapUiComboTreeView1.Location = new System.Drawing.Point(102, 95);
            this.heatmapUiComboTreeView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.heatmapUiComboTreeView1.MinimumSize = new System.Drawing.Size(63, 0);
            this.heatmapUiComboTreeView1.Name = "heatmapUiComboTreeView1";
            treeNode547.Name = "节点0";
            treeNode547.Text = "Autumn";
            treeNode548.Name = "节点0";
            treeNode548.Text = "Bone";
            treeNode549.Name = "节点1";
            treeNode549.Text = "Jet";
            treeNode550.Name = "节点2";
            treeNode550.Text = "Winter";
            treeNode551.Name = "节点3";
            treeNode551.Text = "Rainbow";
            treeNode552.Name = "节点4";
            treeNode552.Text = "Ocean";
            treeNode553.Name = "节点5";
            treeNode553.Text = "Summer";
            treeNode554.Name = "节点6";
            treeNode554.Text = "Spring";
            treeNode555.Name = "节点7";
            treeNode555.Text = "Cool";
            treeNode556.Name = "节点8";
            treeNode556.Text = "Hsv";
            treeNode557.Name = "节点9";
            treeNode557.Text = "Pink";
            treeNode558.Name = "节点10";
            treeNode558.Text = "Hot";
            treeNode559.Name = "节点11";
            treeNode559.Text = "Parula";
            treeNode560.Name = "节点12";
            treeNode560.Text = "Magma";
            treeNode561.Name = "节点13";
            treeNode561.Text = "Inferno";
            treeNode562.Name = "节点14";
            treeNode562.Text = "Plasma";
            treeNode563.Name = "节点15";
            treeNode563.Text = "Viridis";
            treeNode564.Name = "节点16";
            treeNode564.Text = "Cividis";
            treeNode565.Name = "节点17";
            treeNode565.Text = "Twilight";
            treeNode566.Name = "节点18";
            treeNode566.Text = "TwilightShifted";
            treeNode567.Name = "节点19";
            treeNode567.Text = "Turbo";
            this.heatmapUiComboTreeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode547,
            treeNode548,
            treeNode549,
            treeNode550,
            treeNode551,
            treeNode552,
            treeNode553,
            treeNode554,
            treeNode555,
            treeNode556,
            treeNode557,
            treeNode558,
            treeNode559,
            treeNode560,
            treeNode561,
            treeNode562,
            treeNode563,
            treeNode564,
            treeNode565,
            treeNode566,
            treeNode567});
            this.heatmapUiComboTreeView1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.heatmapUiComboTreeView1.Size = new System.Drawing.Size(150, 29);
            this.heatmapUiComboTreeView1.TabIndex = 82;
            this.heatmapUiComboTreeView1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.heatmapUiComboTreeView1.Visible = false;
            this.heatmapUiComboTreeView1.Watermark = "";
            this.heatmapUiComboTreeView1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // imageFormatLabel1
            // 
            this.imageFormatLabel1.AutoSize = true;
            this.imageFormatLabel1.Location = new System.Drawing.Point(11, 27);
            this.imageFormatLabel1.Name = "imageFormatLabel1";
            this.imageFormatLabel1.Size = new System.Drawing.Size(90, 21);
            this.imageFormatLabel1.TabIndex = 83;
            this.imageFormatLabel1.Text = "图像格式：";
            // 
            // testModeLabel2
            // 
            this.testModeLabel2.AutoSize = true;
            this.testModeLabel2.Location = new System.Drawing.Point(11, 64);
            this.testModeLabel2.Name = "testModeLabel2";
            this.testModeLabel2.Size = new System.Drawing.Size(90, 21);
            this.testModeLabel2.TabIndex = 84;
            this.testModeLabel2.Text = "测试模式：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.uiButton1_Load_Img);
            this.groupBox1.Controls.Add(this.uiButton2_SaveImg);
            this.groupBox1.Location = new System.Drawing.Point(378, 524);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(137, 168);
            this.groupBox1.TabIndex = 86;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "图像操作";
            // 
            // upperThresholdLabel3
            // 
            this.upperThresholdLabel3.AutoSize = true;
            this.upperThresholdLabel3.Location = new System.Drawing.Point(11, 99);
            this.upperThresholdLabel3.Name = "upperThresholdLabel3";
            this.upperThresholdLabel3.Size = new System.Drawing.Size(90, 21);
            this.upperThresholdLabel3.TabIndex = 87;
            this.upperThresholdLabel3.Text = "阈值上限：";
            this.upperThresholdLabel3.Visible = false;
            // 
            // lowerThresholdLabel4
            // 
            this.lowerThresholdLabel4.AutoSize = true;
            this.lowerThresholdLabel4.Location = new System.Drawing.Point(11, 129);
            this.lowerThresholdLabel4.Name = "lowerThresholdLabel4";
            this.lowerThresholdLabel4.Size = new System.Drawing.Size(90, 21);
            this.lowerThresholdLabel4.TabIndex = 88;
            this.lowerThresholdLabel4.Text = "阈值下限：";
            this.lowerThresholdLabel4.Visible = false;
            // 
            // upThresholdTextBox1
            // 
            this.upThresholdTextBox1.Location = new System.Drawing.Point(102, 95);
            this.upThresholdTextBox1.Name = "upThresholdTextBox1";
            this.upThresholdTextBox1.Size = new System.Drawing.Size(100, 29);
            this.upThresholdTextBox1.TabIndex = 89;
            this.upThresholdTextBox1.Text = "0";
            // 
            // lowThresholdTextBox2
            // 
            this.lowThresholdTextBox2.Location = new System.Drawing.Point(102, 131);
            this.lowThresholdTextBox2.Name = "lowThresholdTextBox2";
            this.lowThresholdTextBox2.Size = new System.Drawing.Size(100, 29);
            this.lowThresholdTextBox2.TabIndex = 90;
            this.lowThresholdTextBox2.Text = "0";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lowThresholdTextBox2);
            this.groupBox2.Controls.Add(this.heatMapLabel1);
            this.groupBox2.Controls.Add(this.heatmapUiComboTreeView1);
            this.groupBox2.Controls.Add(this.upperThresholdLabel3);
            this.groupBox2.Controls.Add(this.upThresholdTextBox1);
            this.groupBox2.Controls.Add(this.lowerThresholdLabel4);
            this.groupBox2.Controls.Add(this.uiComboBox1);
            this.groupBox2.Controls.Add(this.uiComboBox2);
            this.groupBox2.Controls.Add(this.imageFormatLabel1);
            this.groupBox2.Controls.Add(this.testModeLabel2);
            this.groupBox2.Location = new System.Drawing.Point(2, 524);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(272, 168);
            this.groupBox2.TabIndex = 91;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "测试参数选择";
            // 
            // heatMapLabel1
            // 
            this.heatMapLabel1.AutoSize = true;
            this.heatMapLabel1.Location = new System.Drawing.Point(11, 99);
            this.heatMapLabel1.Name = "heatMapLabel1";
            this.heatMapLabel1.Size = new System.Drawing.Size(90, 21);
            this.heatMapLabel1.TabIndex = 91;
            this.heatMapLabel1.Text = "颜色类型：";
            this.heatMapLabel1.Visible = false;
            // 
            // pixelValueLabel1
            // 
            this.pixelValueLabel1.AutoSize = true;
            this.pixelValueLabel1.Location = new System.Drawing.Point(5, 29);
            this.pixelValueLabel1.Name = "pixelValueLabel1";
            this.pixelValueLabel1.Size = new System.Drawing.Size(90, 21);
            this.pixelValueLabel1.TabIndex = 92;
            this.pixelValueLabel1.Text = "像素信息：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pixelValueLabel1);
            this.groupBox3.Location = new System.Drawing.Point(520, 524);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(303, 168);
            this.groupBox3.TabIndex = 93;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "像素信息";
            // 
            // SingleImageProcessMode
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(824, 720);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "SingleImageProcessMode";
            this.Text = "单图像处理";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIButton uiButton1_Load_Img;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Sunny.UI.UIButton uiButton2_SaveImg;
        private Sunny.UI.UIComboBox uiComboBox1;
        private Sunny.UI.UIComboBox uiComboBox2;
        private Sunny.UI.UIComboTreeView heatmapUiComboTreeView1;
        private System.Windows.Forms.Label imageFormatLabel1;
        private System.Windows.Forms.Label testModeLabel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label upperThresholdLabel3;
        private System.Windows.Forms.Label lowerThresholdLabel4;
        private System.Windows.Forms.TextBox upThresholdTextBox1;
        private System.Windows.Forms.TextBox lowThresholdTextBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label heatMapLabel1;
        private System.Windows.Forms.Label pixelValueLabel1;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}