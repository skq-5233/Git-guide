find ./background -maxdepth 4 -name "*.jpg" | sort > train.txt
find ./crops -maxdepth 4 -name "*.jpg" | sort > small.txt
